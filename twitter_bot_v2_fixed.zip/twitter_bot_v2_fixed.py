
import requests
import time
from telegram import Bot

# === Настройки ===
BEARER_TOKEN = 'AAAAAAAAAAAAAAAAAAAAAApZ0gEAAAAAuvPoa1wLnjYCgPOy+yLqeRTRsVI=N4omuheVUswFfkN6QynXmSsrhoIipLpEIOv8b3saiSskRUEJ7d'
TELEGRAM_BOT_TOKEN = '7828846852:AAHQUx9c_2epvYnRXpzIj7kZPe1TfBtkwJ8'
TELEGRAM_CHAT_ID = '352912484'

bot = Bot(token=TELEGRAM_BOT_TOKEN)

# Клубы Колумбии
accounts = [
    "MillosFCoficial", "nacionaloficial", "SantaFe", "JuniorClubSA", "AmericadeCali",
    "AsoDeporCali", "DIM_Oficial", "oncecaldas", "cdtolima", "ABucaramanga",
    "BoyacaChicoFC", "DeporPasto", "EnvigadoFC", "patriotasboySA", "JaguaresdeCord",
    "AguilasDoradas", "Equidadfutbol", "FortalezaCEIF", "FCPereira", "APetrolera"
]

# Ключевые слова
keywords = [
    "convocados", "alineación", "once inicial", "XI titular", "equipo titular", "equipo alternativo",
    "formación", "lista de convocados", "lesión", "lesionado", "lesionados", "bajas",
    "bajas importantes", "ausencia", "ausencias", "no disponible", "problemas físicos",
    "molestias musculares", "problemas médicos", "no jugará", "no estará", "recuperación",
    "suspendido", "expulsado", "sancionado", "parte médico", "fuera de la convocatoria"
]

seen_tweets = {}

def get_tweets(username):
    url = f"https://api.twitter.com/2/tweets/search/recent?query=from:{username}&tweet.fields=text&max_results=5"
    headers = {"Authorization": f"Bearer {BEARER_TOKEN}"}
    response = requests.get(url, headers=headers)
    return response.json()

def check():
    for username in accounts:
        data = get_tweets(username)
        if 'data' not in data:
            continue
        for tweet in data['data']:
            text = tweet['text'].lower()
            tweet_id = tweet['id']

            if seen_tweets.get(username) == tweet_id:
                continue

            if any(word.lower() in text for word in keywords):
                link = f"https://x.com/{username}/status/{tweet_id}"
                message = "📢 @{}\n\n{}\n\n🔗 {}".format(username, text, link)
                bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=message)
                seen_tweets[username] = tweet_id

while True:
    try:
        check()
        time.sleep(90)
    except Exception as e:
        print(f"Ошибка: {e}")
        time.sleep(60)
